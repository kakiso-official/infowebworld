(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[725],{1408:(e,a,r)=>{"use strict";r.d(a,{F1:()=>m,QM:()=>p,YQ:()=>s,fo:()=>n,gJ:()=>c,i7:()=>h,qB:()=>d,qT:()=>o});let l="/infowebworld/api.php";function i(e){if(!e)return[];if("string"==typeof e)try{return JSON.parse(e)}catch{return[]}return Array.isArray(e)?e:[]}function t(e){return{id:String(e.id??""),companyName:String(e.company_name??""),contactName:String(e.contact_name??""),email:String(e.email??""),phoneCode:String(e.phone_code??"+1"),phone:String(e.phone??""),website:String(e.website??""),category:String(e.category_name??e.category??""),categorySlug:String(e.category_slug??""),categoryColor:String(e.category_color??"#E8553D"),categoryIcon:String(e.category_icon??"grid"),country:String(e.country_name??e.country??""),city:String(e.city??""),tagline:String(e.tagline??""),description:String(e.description??""),slug:String(e.slug??""),logoUrl:String(e.logo_url??""),screenshots:i(e.screenshots),demoVideo:String(e.demo_video??""),features:i(e.features),integrations:i(e.integrations),pricingModel:String(e.pricing_model??"contact"),pricingTiers:i(e.pricing_tiers),founded:String(e.founded_year??""),employees:String(e.team_size??""),funding:String(e.funding??""),hqLocation:String(e.hq_location??""),linkedin:String(e.linkedin??""),twitter:String(e.twitter??""),facebook:String(e.facebook??""),plan:String(e.plan_slug??e.plan??""),planName:String(e.plan_name??""),status:e.status||"pending",submittedAt:String(e.created_at??""),approvedAt:String(e.approved_at??"")}}async function n(){try{let e=await fetch(`${l}?action=submission_list`);if(!e.ok)return[];return(await e.json()).map(t)}catch{return[]}}async function s(){let e=await n();return{total:e.length,pending:e.filter(e=>"pending"===e.status).length,confirmed:e.filter(e=>"confirmed"===e.status).length,paid:e.filter(e=>"paid"===e.status).length,active:e.filter(e=>"active"===e.status).length}}async function o(e,a){await fetch(`${l}?action=submission_status`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:Number(e),status:a})}).catch(()=>{})}async function d(e){await fetch(`${l}?action=submission_delete`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:Number(e)})}).catch(()=>{})}async function c(e){return(await fetch(`${l}?action=submission_create`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e)})).json()}async function p(e,a){let r=new FormData;r.append("file",e),r.append("type",a);let i=await fetch(`${l}?action=file_upload`,{method:"POST",body:r}),t=await i.json();if(t.url)return t.url;throw Error(t.error||"Upload failed")}async function m(e){try{let a=await fetch(`${l}?action=listing_get&slug=${encodeURIComponent(e)}`);if(!a.ok)return null;let r=await a.json();if(r.error)return null;return{listing:t(r.listing),breadcrumb:r.breadcrumb,related:(r.related||[]).map(e=>t(e))}}catch{return null}}async function h(e,a=1){try{let r=await fetch(`${l}?action=category_listings&category_id=${e}&page=${a}`);if(!r.ok)return{data:[],total:0,page:1};let i=await r.json();return{data:(i.data||[]).map(e=>t(e)),total:i.total||0,page:i.page||1}}catch{return{data:[],total:0,page:1}}}},5340:(e,a,r)=>{Promise.resolve().then(r.bind(r,1761)),Promise.resolve().then(r.bind(r,8637)),Promise.resolve().then(r.bind(r,7691)),Promise.resolve().then(r.t.bind(r,4573,23))},7691:(e,a,r)=>{"use strict";r.d(a,{default:()=>y});var l=r(7326),i=r(286),t=r(4573),n=r.n(t),s=r(1408);let o=({d:e,size:a=18,color:r="currentColor",sw:i=1.5})=>(0,l.jsx)("svg",{width:a,height:a,viewBox:"0 0 24 24",fill:"none",stroke:r,strokeWidth:i,strokeLinecap:"round",strokeLinejoin:"round",children:e.split("|").map((e,a)=>(0,l.jsx)("path",{d:e},a))}),d="M20 6L9 17l-5-5",c="M12 2a10 10 0 100 20 10 10 0 000-20z|M2 12h20|M12 2a15 15 0 014 10 15 15 0 01-4 10 15 15 0 01-4-10A15 15 0 0112 2z",p="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z|M22 6l-10 7L2 6",m="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6|M15 3h6v6|M10 14L21 3",h="M19 4H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2V6a2 2 0 00-2-2z|M16 2v4|M8 2v4|M3 10h18",g="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z|M12 7a3 3 0 100 6 3 3 0 000-6z",x="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2|M9 3a4 4 0 100 8 4 4 0 000-8z|M23 21v-2a4 4 0 00-3-3.87|M16 3.13a4 4 0 010 7.75",f="M12 1v22|M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6",b="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z|M7 7h.01",u="M13 2L3 14h9l-1 8 10-12h-9l1-8z";function y(){let[e,a]=(0,i.useState)(null),[r,t]=(0,i.useState)([]),[y,v]=(0,i.useState)([]),[w,j]=(0,i.useState)(!1),[N,k]=(0,i.useState)(!0),[z,M]=(0,i.useState)(null),S=(0,i.useRef)(null);if((0,i.useEffect)(()=>{let e=window.location.pathname.match(/\/listing\/(.+?)(?:\/|$)/);if(!e){j(!0),k(!1);return}(0,s.F1)(e[1]).then(e=>{e?(a(e.listing),t(e.breadcrumb),v(e.related)):j(!0),k(!1)})},[]),(0,i.useEffect)(()=>{if(!e)return;document.title=`${e.companyName} | InfoWebWorld`;let a=(e,a)=>{let r=document.querySelector(`meta[name="${e}"]`)||document.querySelector(`meta[property="${e}"]`);r||((r=document.createElement("meta")).setAttribute(e.startsWith("og:")?"property":"name",e),document.head.appendChild(r)),r.setAttribute("content",a)};a("description",e.tagline||`${e.companyName} on InfoWebWorld`),a("og:title",e.companyName),a("og:description",e.tagline||""),e.logoUrl&&a("og:image",e.logoUrl)},[e]),N)return null;if(w)return(0,l.jsx)("section",{className:"ld",style:{display:"flex",alignItems:"center",justifyContent:"center",minHeight:"60vh",padding:"3rem 1rem"},children:(0,l.jsxs)("div",{className:"ld-card",style:{textAlign:"center",maxWidth:420,padding:"clamp(2rem, 5vw, 3rem)"},children:[(0,l.jsx)("div",{style:{width:56,height:56,borderRadius:14,background:"#E8553D0A",display:"inline-flex",alignItems:"center",justifyContent:"center",marginBottom:"1rem"},children:(0,l.jsx)(o,{d:"M11 3a8 8 0 100 16 8 8 0 000-16z|M21 21l-4.35-4.35",size:24,color:"#E8553D"})}),(0,l.jsx)("h1",{className:"ld-h2",children:"Listing Not Found"}),(0,l.jsx)("p",{className:"ld-body",style:{maxWidth:340,margin:"0 auto .85rem"},children:"This listing doesn't exist or hasn't been published yet."}),(0,l.jsx)(n(),{href:"/categories",className:"ld-btn-primary",children:"Browse Categories"})]})});if(!e)return null;let $=e.categoryColor||"#E8553D",A="active"===e.status||"founding"===e.plan,_=e.companyName.charAt(0).toUpperCase();return(0,l.jsxs)("section",{className:"ld",children:[(0,l.jsxs)("div",{className:"ld-wrap",children:[(0,l.jsxs)("div",{className:"ld-card ld-hero-card",children:[(0,l.jsxs)("div",{className:"ld-banner",style:{background:`linear-gradient(135deg, ${$}20, ${$}0D 40%, #FAF5F0CC 70%, #FAF5F0)`},children:[(0,l.jsx)("div",{className:"ld-banner-mesh",style:{background:`radial-gradient(ellipse 80% 60% at 15% 20%, ${$}18, transparent 60%), radial-gradient(ellipse 60% 80% at 85% 70%, ${$}10, transparent 50%)`}}),(0,l.jsx)("div",{className:"ld-banner-dots",style:{backgroundImage:`radial-gradient(${$}88 0.8px, transparent 0.8px)`}}),(0,l.jsx)("div",{className:"ld-banner-lines",style:{backgroundImage:`repeating-linear-gradient(45deg, ${$}, ${$} 1px, transparent 1px, transparent 16px)`}}),(0,l.jsx)("div",{className:"ld-banner-shape ld-banner-shape--1",style:{background:$}}),(0,l.jsx)("div",{className:"ld-banner-shape ld-banner-shape--2",style:{background:$}}),(0,l.jsx)("div",{className:"ld-banner-shape ld-banner-shape--3",style:{background:$}}),(0,l.jsxs)("nav",{className:"ld-crumbs",children:[(0,l.jsxs)(n(),{href:"/",className:"ld-crumb",children:[(0,l.jsx)(o,{d:"M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z|M9 22V12h6v10",size:10,sw:2})," Home"]}),(0,l.jsx)("span",{className:"ld-crumb-sep",children:"/"}),(0,l.jsx)(n(),{href:"/categories",className:"ld-crumb",children:"Categories"}),r.map((e,a)=>(0,l.jsxs)("span",{style:{display:"contents"},children:[(0,l.jsx)("span",{className:"ld-crumb-sep",children:"/"}),(0,l.jsx)(n(),{href:`/category/${e.slug}`,className:"ld-crumb ld-crumb--cat",style:{color:$,background:`${$}14`},children:e.name})]},a)),(0,l.jsx)("span",{className:"ld-crumb-sep",children:"/"}),(0,l.jsx)("span",{className:"ld-crumb ld-crumb--current",children:e.companyName})]})]}),(0,l.jsxs)("div",{className:"ld-hero-body",children:[(0,l.jsxs)("div",{className:"ld-logo",style:{background:e.logoUrl?"#fff":`linear-gradient(135deg, ${$}22, ${$}44)`,borderColor:e.logoUrl?"#E8E3DE":`${$}20`},children:[e.logoUrl?(0,l.jsx)("img",{src:e.logoUrl,alt:e.companyName,onError:e=>{e.target.style.display="none";let a=e.target.nextElementSibling;a&&(a.style.display="flex")}}):null,(0,l.jsx)("span",{className:"ld-logo-fallback",style:{color:$,display:e.logoUrl?"none":"flex"},children:_})]}),(0,l.jsxs)("div",{className:"ld-hero-info",children:[(0,l.jsx)("h1",{className:"ld-title",children:e.companyName}),e.tagline&&(0,l.jsx)("p",{className:"ld-tagline",children:e.tagline}),(0,l.jsxs)("div",{className:"ld-badges",children:[(0,l.jsxs)("span",{className:"ld-badge",style:{color:$,background:`${$}10`},children:[(0,l.jsx)(o,{d:b,size:10,color:$,sw:2})," ",e.category]}),A&&(0,l.jsxs)("span",{className:"ld-badge",style:{color:"#2FAE6A",background:"#2FAE6A12"},children:[(0,l.jsx)(o,{d:"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z",size:10,color:"#2FAE6A",sw:2})," Verified"]}),e.planName&&(0,l.jsxs)("span",{className:"ld-badge",style:{color:"#C89200",background:"#E5A10012"},children:[(0,l.jsx)("svg",{width:10,height:10,viewBox:"0 0 24 24",fill:"#E5A100",stroke:"none",children:(0,l.jsx)("path",{d:"M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"})}),e.planName]})]}),(e.hqLocation||e.founded||e.employees)&&(0,l.jsxs)("div",{className:"ld-meta-row",children:[e.hqLocation&&(0,l.jsxs)("span",{className:"ld-meta",children:[(0,l.jsx)(o,{d:g,size:11,color:"#9A9590",sw:2})," ",e.hqLocation]}),e.founded&&(0,l.jsxs)("span",{className:"ld-meta",children:[(0,l.jsx)(o,{d:h,size:11,color:"#9A9590",sw:2})," Founded ",e.founded]}),e.employees&&(0,l.jsxs)("span",{className:"ld-meta",children:[(0,l.jsx)(o,{d:x,size:11,color:"#9A9590",sw:2})," ",e.employees]})]}),(0,l.jsxs)("div",{className:"ld-actions",children:[e.website&&(0,l.jsxs)("a",{href:e.website,target:"_blank",rel:"noopener noreferrer",className:"ld-btn-primary",style:{background:$,borderColor:$},children:[(0,l.jsx)(o,{d:m,size:13,color:"#fff",sw:2})," Visit Website"]}),(0,l.jsxs)("a",{href:`mailto:${e.email}`,className:"ld-btn-outline",children:[(0,l.jsx)(o,{d:p,size:13,sw:2})," Contact"]})]})]})]})]}),(0,l.jsxs)("div",{className:"ld-grid",children:[(0,l.jsxs)("div",{className:"ld-main",children:[(e.description||e.features?.length>0||e.integrations?.length>0)&&(0,l.jsxs)("div",{className:"ld-card ld-section",children:[e.description&&(0,l.jsxs)("div",{className:"ld-block",children:[(0,l.jsxs)("h2",{className:"ld-h3",children:[(0,l.jsx)(o,{d:"M12 2L2 7l10 5 10-5-10-5z|M2 17l10 5 10-5|M2 12l10 5 10-5",size:16,color:$,sw:2})," Overview"]}),(0,l.jsx)("p",{className:"ld-body",style:{whiteSpace:"pre-line"},children:e.description})]}),e.features?.length>0&&(0,l.jsxs)("div",{className:"ld-block",children:[(0,l.jsxs)("h3",{className:"ld-h3",children:[(0,l.jsx)(o,{d:d,size:15,color:"#2FAE6A",sw:2.5})," Key Features"]}),(0,l.jsx)("div",{className:"ld-features",children:e.features.map((e,a)=>(0,l.jsxs)("div",{className:"ld-feature",children:[(0,l.jsx)("span",{className:"ld-feature-dot",children:(0,l.jsx)(o,{d:d,size:11,color:"#2FAE6A",sw:2.5})}),(0,l.jsx)("span",{children:e})]},a))})]}),e.integrations?.length>0&&(0,l.jsxs)("div",{className:"ld-block",children:[(0,l.jsxs)("h3",{className:"ld-h3",children:[(0,l.jsx)(o,{d:u,size:15,color:$,sw:2})," Integrations"]}),(0,l.jsx)("div",{className:"ld-tags",children:e.integrations.map((e,a)=>(0,l.jsxs)("span",{className:"ld-tag",children:[(0,l.jsx)(o,{d:u,size:10,color:$,sw:2})," ",e]},a))})]})]}),e.screenshots?.length>0&&(0,l.jsxs)("div",{className:"ld-card ld-section",children:[(0,l.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12},children:[(0,l.jsxs)("h2",{className:"ld-h3",style:{margin:0},children:[(0,l.jsx)(o,{d:"M19 3H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2V5a2 2 0 00-2-2z|M8.5 10a1.5 1.5 0 100-3 1.5 1.5 0 000 3z|M21 15l-5-5L5 21",size:16,color:$,sw:2})," Screenshots"]}),e.screenshots.length>1&&(0,l.jsxs)("div",{style:{display:"flex",gap:4},children:[(0,l.jsx)("button",{onClick:()=>S.current?.scrollBy({left:-280,behavior:"smooth"}),className:"ld-gallery-btn",children:(0,l.jsx)(o,{d:"M15 18l-6-6 6-6",size:13,sw:2})}),(0,l.jsx)("button",{onClick:()=>S.current?.scrollBy({left:280,behavior:"smooth"}),className:"ld-gallery-btn",children:(0,l.jsx)(o,{d:"M9 18l6-6-6-6",size:13,sw:2})})]})]}),(0,l.jsx)("div",{ref:S,className:"ld-gallery",children:e.screenshots.map((e,a)=>(0,l.jsx)("div",{className:"ld-gallery-item",onClick:()=>M(e),children:(0,l.jsx)("img",{src:e,alt:`Screenshot ${a+1}`})},a))})]}),e.pricingTiers?.length>0&&(0,l.jsxs)("div",{className:"ld-card ld-section",children:[(0,l.jsxs)("h2",{className:"ld-h3",children:[(0,l.jsx)(o,{d:f,size:16,color:$,sw:2})," Pricing"]}),(0,l.jsx)("div",{className:"ld-pricing",children:e.pricingTiers.map((e,a)=>(0,l.jsxs)("div",{className:"ld-price-card",children:[(0,l.jsx)("div",{className:"ld-price-bar",style:{background:`linear-gradient(90deg, ${$}40, ${$}10)`}}),(0,l.jsx)("p",{className:"ld-price-name",children:e.name}),(0,l.jsx)("p",{className:"ld-price-amount",children:e.price?`$${e.price}`:"Custom"}),e.period&&(0,l.jsx)("p",{className:"ld-price-period",children:e.period})]},a))}),e.pricingModel&&(0,l.jsxs)("p",{className:"ld-body-sm",style:{marginTop:10},children:[(0,l.jsx)(o,{d:b,size:11,color:"#9A9590",sw:2})," Model: ",e.pricingModel]})]})]}),(0,l.jsxs)("aside",{className:"ld-sidebar",children:[(e.founded||e.hqLocation||e.employees||e.funding||e.website)&&(0,l.jsxs)("div",{className:"ld-card ld-side-card",children:[(0,l.jsxs)("h3",{className:"ld-side-title",children:[(0,l.jsx)(o,{d:"M4 2h16a1 1 0 011 1v18a1 1 0 01-1 1H4a1 1 0 01-1-1V3a1 1 0 011-1z|M9 22v-4h6v4|M8 6h.01M16 6h.01M12 6h.01M8 10h.01M16 10h.01M12 10h.01M8 14h.01M16 14h.01M12 14h.01",size:14,color:$,sw:2})," Quick Facts"]}),(0,l.jsxs)("div",{className:"ld-facts",children:[[e.founded&&{icon:h,label:"Founded",val:e.founded},e.hqLocation&&{icon:g,label:"HQ",val:e.hqLocation},e.employees&&{icon:x,label:"Team",val:e.employees},e.funding&&{icon:f,label:"Funding",val:e.funding}].filter(Boolean).map((e,a)=>e&&(0,l.jsxs)("div",{className:"ld-fact",children:[(0,l.jsx)("div",{className:"ld-fact-icon",style:{background:`${$}08`},children:(0,l.jsx)(o,{d:e.icon,size:13,color:$,sw:2})}),(0,l.jsxs)("div",{children:[(0,l.jsx)("p",{className:"ld-fact-label",children:e.label}),(0,l.jsx)("p",{className:"ld-fact-val",children:e.val})]})]},a)),e.website&&(0,l.jsxs)("div",{className:"ld-fact",children:[(0,l.jsx)("div",{className:"ld-fact-icon",style:{background:`${$}08`},children:(0,l.jsx)(o,{d:c,size:13,color:$,sw:2})}),(0,l.jsxs)("div",{style:{minWidth:0},children:[(0,l.jsx)("p",{className:"ld-fact-label",children:"Website"}),(0,l.jsx)("a",{href:e.website,target:"_blank",rel:"noopener noreferrer",className:"ld-fact-link",children:e.website.replace(/^https?:\/\//,"").replace(/\/$/,"")})]})]})]})]}),(e.linkedin||e.twitter||e.facebook)&&(0,l.jsxs)("div",{className:"ld-card ld-side-card",children:[(0,l.jsxs)("h3",{className:"ld-side-title",children:[(0,l.jsx)(o,{d:c,size:14,color:$,sw:2})," Social"]}),(0,l.jsxs)("div",{className:"ld-socials",children:[e.linkedin&&(0,l.jsxs)("a",{href:e.linkedin,target:"_blank",rel:"noopener noreferrer",className:"ld-social",children:[(0,l.jsx)("span",{className:"ld-social-icon",style:{background:"#0077B514"},children:(0,l.jsx)(o,{d:"M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-4 0v7h-4v-7a6 6 0 016-6z|M2 9h4v12H2z|M4 2a2 2 0 100 4 2 2 0 000-4z",size:13,color:"#0077B5",sw:2})})," LinkedIn ",(0,l.jsx)(o,{d:m,size:10,color:"#9A9590",sw:2})]}),e.twitter&&(0,l.jsxs)("a",{href:e.twitter,target:"_blank",rel:"noopener noreferrer",className:"ld-social",children:[(0,l.jsx)("span",{className:"ld-social-icon",style:{background:"#1DA1F214"},children:(0,l.jsx)(o,{d:"M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z",size:13,color:"#1DA1F2",sw:2})})," Twitter ",(0,l.jsx)(o,{d:m,size:10,color:"#9A9590",sw:2})]}),e.facebook&&(0,l.jsxs)("a",{href:e.facebook,target:"_blank",rel:"noopener noreferrer",className:"ld-social",children:[(0,l.jsx)("span",{className:"ld-social-icon",style:{background:"#1877F214"},children:(0,l.jsx)(o,{d:"M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z",size:13,color:"#1877F2",sw:2})})," Facebook ",(0,l.jsx)(o,{d:m,size:10,color:"#9A9590",sw:2})]})]})]}),(0,l.jsxs)("div",{className:"ld-side-cta",style:{background:`linear-gradient(135deg, ${$}12, ${$}06)`,borderColor:`${$}20`},children:[(0,l.jsx)("div",{className:"ld-side-cta-icon",style:{background:`${$}14`},children:(0,l.jsx)(o,{d:p,size:18,color:$,sw:2})}),(0,l.jsx)("h3",{className:"ld-side-cta-title",children:"Interested?"}),(0,l.jsxs)("p",{className:"ld-body-sm",children:["Get in touch with ",e.companyName," to learn more."]}),(0,l.jsxs)("a",{href:`mailto:${e.email}`,className:"ld-btn-primary ld-btn-full",style:{background:$,borderColor:$},children:[(0,l.jsx)(o,{d:p,size:13,color:"#fff",sw:2})," Send Inquiry"]})]})]})]}),y.length>0&&(0,l.jsxs)("div",{className:"ld-card ld-section",style:{marginTop:16},children:[(0,l.jsxs)("h2",{className:"ld-h3",children:[(0,l.jsx)(o,{d:"M3 3h7v7H3z|M14 3h7v7h-7z|M3 14h7v7H3z|M14 14h7v7h-7z",size:16,color:$,sw:2})," Related Listings"]}),(0,l.jsx)("div",{className:"ld-related",children:y.map(e=>{let a=e.categoryColor||"#E8553D";return(0,l.jsxs)(n(),{href:`/listing/${e.slug}`,className:"ld-related-card",children:[(0,l.jsx)("div",{className:"ld-related-logo",style:{background:e.logoUrl?"#fff":`linear-gradient(135deg, ${a}22, ${a}44)`,borderColor:e.logoUrl?"#E8E3DE":`${a}20`},children:e.logoUrl?(0,l.jsx)("img",{src:e.logoUrl,alt:e.companyName}):(0,l.jsx)("span",{style:{color:a,fontFamily:"var(--font-bricolage)",fontWeight:800,fontSize:"1rem"},children:e.companyName.charAt(0)})}),(0,l.jsxs)("div",{style:{flex:1,minWidth:0},children:[(0,l.jsx)("p",{className:"ld-related-name",children:e.companyName}),e.tagline&&(0,l.jsx)("p",{className:"ld-related-tagline",children:e.tagline}),(0,l.jsxs)("span",{className:"ld-badge",style:{color:a,background:`${a}10`,fontSize:".6rem",padding:"2px 8px"},children:[(0,l.jsx)(o,{d:b,size:8,color:a,sw:2})," ",e.category]})]}),(0,l.jsx)("span",{className:"ld-related-arrow",children:(0,l.jsx)(o,{d:"M5 12h14|M12 5l7 7-7 7",size:13})})]},e.id)})})]}),(0,l.jsxs)(n(),{href:"/categories",className:"ld-back",children:[(0,l.jsx)(o,{d:"M19 12H5|M12 19l-7-7 7-7",size:13,sw:2})," Back to Categories"]})]}),z&&(0,l.jsxs)("div",{className:"ld-lightbox",onClick:()=>M(null),children:[(0,l.jsx)("button",{onClick:e=>{e.stopPropagation(),M(null)},className:"ld-lightbox-close",children:(0,l.jsx)(o,{d:"M18 6L6 18|M6 6l12 12",size:18,color:"#fff",sw:2})}),(0,l.jsx)("img",{src:z,alt:"Screenshot"})]}),(0,l.jsx)("style",{children:`
        /* ══════════════════════════════════════════
           LISTING DETAIL — Compact, Responsive
           ══════════════════════════════════════════ */
        .ld { background: var(--h-bg); padding: clamp(1rem, 3vw, 2rem) 0 clamp(2rem, 4vw, 3rem); overflow-x: hidden }
        .ld-wrap { max-width: 1100px; margin: 0 auto; padding: 0 clamp(.75rem, 2.5vw, 1.5rem); overflow: hidden }
        .ld-card { background: #fff; border-radius: 20px; border: 1.5px solid var(--h-border); overflow: hidden; max-width: 100% }
        .ld-section { padding: clamp(1rem, 2.5vw, 1.5rem) }
        .ld-h2 { font-family: var(--font-bricolage); font-weight: 800; font-size: clamp(1.2rem, 3vw, 1.6rem); color: var(--h-heading); margin: 0 0 .4rem; line-height: 1.15 }
        .ld-h3 { font-family: var(--font-bricolage); font-weight: 800; font-size: clamp(.9rem, 2vw, 1.05rem); color: var(--h-heading); margin: 0 0 .75rem; display: flex; align-items: center; gap: 7px }
        .ld-body { font-family: var(--font-nunito); font-size: clamp(.82rem, 1.8vw, .9rem); color: var(--h-body); line-height: 1.65; margin: 0 }
        .ld-body-sm { font-family: var(--font-nunito); font-size: .75rem; color: var(--h-muted); line-height: 1.5; margin: 0 }
        .ld-block { margin-bottom: clamp(1rem, 2.5vw, 1.5rem) }
        .ld-block:last-child { margin-bottom: 0 }

        /* ── Banner ── */
        .ld-hero-card { margin-bottom: 16px }
        .ld-banner {
          position: relative; overflow: hidden;
          padding: clamp(1.5rem, 4vw, 2.5rem) clamp(1rem, 2.5vw, 1.5rem) clamp(1rem, 2.5vw, 1.5rem);
          min-height: clamp(80px, 14vw, 130px);
          display: flex; align-items: flex-end;
        }
        .ld-banner-mesh, .ld-banner-dots, .ld-banner-lines { position: absolute; inset: 0 }
        .ld-banner-mesh { opacity: 1 }
        .ld-banner-dots { opacity: .2; background-size: 18px 18px }
        .ld-banner-lines { opacity: .04 }
        .ld-banner-shape { position: absolute; border-radius: 50%; opacity: .04 }
        .ld-banner-shape--1 { width: 160px; height: 160px; top: -60px; right: 10% }
        .ld-banner-shape--2 { width: 100px; height: 100px; bottom: -40px; left: 5% }
        .ld-banner-shape--3 { width: 50px; height: 50px; border-radius: 14px; top: 25%; left: 55%; transform: rotate(25deg); opacity: .05 }

        /* ── Breadcrumb ── */
        .ld-crumbs { position: relative; z-index: 2; display: flex; flex-wrap: wrap; align-items: center; gap: 5px; font-family: var(--font-nunito); font-size: .68rem }
        .ld-crumb { display: inline-flex; align-items: center; gap: 3px; color: var(--h-muted); text-decoration: none; padding: 2px 8px; border-radius: 999px; background: rgba(255,255,255,.7); backdrop-filter: blur(6px); font-weight: 600; transition: color .2s }
        .ld-crumb:hover { color: var(--h-accent) }
        .ld-crumb--cat { font-weight: 700 }
        .ld-crumb--current { color: var(--h-heading); font-weight: 700; background: rgba(255,255,255,.85) }
        .ld-crumb-sep { color: var(--h-border); font-size: .55rem }

        /* ── Hero body ── */
        .ld-hero-body { padding: clamp(1rem, 2.5vw, 1.5rem); display: flex; gap: clamp(.75rem, 2vw, 1.25rem); align-items: flex-start; overflow: hidden }
        .ld-logo {
          width: clamp(56px, 10vw, 72px); height: clamp(56px, 10vw, 72px);
          border-radius: 18px; flex-shrink: 0; overflow: hidden;
          border: 1.5px solid; display: flex; align-items: center; justify-content: center;
          box-shadow: 0 4px 14px rgba(0,0,0,.05);
        }
        .ld-logo img { width: 100%; height: 100%; object-fit: contain; padding: 3px }
        .ld-logo-fallback { font-family: var(--font-bricolage); font-weight: 800; font-size: clamp(1.4rem, 4vw, 1.8rem); align-items: center; justify-content: center }
        .ld-hero-info { flex: 1; min-width: 0; overflow: hidden }
        .ld-title { font-family: var(--font-bricolage); font-weight: 800; font-size: clamp(1.2rem, 3.5vw, 1.8rem); color: var(--h-heading); margin: 0 0 4px; line-height: 1.15; letter-spacing: -.02em }
        .ld-tagline { font-family: var(--font-nunito); font-size: clamp(.8rem, 1.8vw, .9rem); color: var(--h-body); line-height: 1.5; margin: 0 0 8px; max-width: 100% }

        /* ── Badges ── */
        .ld-badges { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px }
        .ld-badge { display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px; border-radius: 999px; font-family: var(--font-nunito); font-size: .68rem; font-weight: 700 }

        /* ── Meta row ── */
        .ld-meta-row { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 10px }
        .ld-meta { display: inline-flex; align-items: center; gap: 4px; font-family: var(--font-nunito); font-size: .7rem; color: var(--h-muted); font-weight: 600 }

        /* ── Actions ── */
        .ld-actions { display: flex; flex-wrap: wrap; gap: 8px }
        .ld-btn-primary {
          display: inline-flex; align-items: center; gap: 6px;
          padding: 8px 18px; border-radius: 999px; color: #fff;
          font-family: var(--font-nunito); font-weight: 700; font-size: .8rem;
          text-decoration: none; border: 1.5px solid; transition: all .3s cubic-bezier(.16,1,.3,1);
        }
        .ld-btn-primary:hover { transform: translateY(-1px); opacity: .9 }
        .ld-btn-outline {
          display: inline-flex; align-items: center; gap: 6px;
          padding: 8px 18px; border-radius: 999px; background: #fff;
          color: var(--h-heading); font-family: var(--font-nunito); font-weight: 700; font-size: .8rem;
          text-decoration: none; border: 1.5px solid var(--h-border); transition: all .3s cubic-bezier(.16,1,.3,1);
        }
        .ld-btn-outline:hover { border-color: var(--h-accent); color: var(--h-accent); transform: translateY(-1px) }
        .ld-btn-full { width: 100%; justify-content: center }

        /* ── 2-column grid ── */
        .ld-grid { display: grid; grid-template-columns: minmax(0, 1fr) 250px; gap: 16px; align-items: start }
        .ld-main { display: flex; flex-direction: column; gap: 16px; min-width: 0; overflow: hidden }
        .ld-sidebar { display: flex; flex-direction: column; gap: 12px; position: sticky; top: 16px }

        /* ── Features ── */
        .ld-features { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 6px }
        .ld-feature { display: flex; align-items: flex-start; gap: 8px; padding: 8px 10px; border-radius: 10px; background: var(--h-bg); font-family: var(--font-nunito); font-size: .8rem; color: var(--h-heading); font-weight: 600; line-height: 1.35 }
        .ld-feature-dot { width: 20px; height: 20px; border-radius: 6px; flex-shrink: 0; background: #2FAE6A14; display: flex; align-items: center; justify-content: center; margin-top: 1px }

        /* ── Tags ── */
        .ld-tags { display: flex; flex-wrap: wrap; gap: 6px }
        .ld-tag { display: inline-flex; align-items: center; gap: 4px; padding: 5px 12px; border-radius: 999px; background: var(--h-bg); border: 1px solid var(--h-border-light); font-family: var(--font-nunito); font-size: .75rem; font-weight: 600; color: var(--h-body) }

        /* ── Gallery ── */
        .ld-gallery { display: flex; gap: 10px; overflow-x: auto; scroll-snap-type: x mandatory; scrollbar-width: none; -ms-overflow-style: none }
        .ld-gallery::-webkit-scrollbar { display: none }
        .ld-gallery-item { flex-shrink: 0; width: clamp(220px, 40vw, 280px); height: clamp(140px, 25vw, 180px); border-radius: 14px; overflow: hidden; border: 1px solid var(--h-border-light); cursor: pointer; scroll-snap-align: start; transition: transform .3s cubic-bezier(.16,1,.3,1) }
        .ld-gallery-item:hover { transform: scale(1.02) }
        .ld-gallery-item img { width: 100%; height: 100%; object-fit: cover }
        .ld-gallery-btn { width: 28px; height: 28px; border-radius: 8px; border: 1px solid var(--h-border); background: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--h-body); transition: all .2s }
        .ld-gallery-btn:hover { border-color: var(--h-accent); color: var(--h-accent) }

        /* ── Pricing ── */
        .ld-pricing { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 10px }
        .ld-price-card { background: var(--h-bg); border-radius: 16px; border: 1px solid var(--h-border-light); padding: 16px; text-align: center; position: relative; overflow: hidden }
        .ld-price-bar { position: absolute; top: 0; left: 0; right: 0; height: 3px; border-radius: 16px 16px 0 0 }
        .ld-price-name { font-family: var(--font-nunito); font-weight: 700; font-size: .72rem; color: var(--h-muted); text-transform: uppercase; letter-spacing: .04em; margin: 0 0 4px }
        .ld-price-amount { font-family: var(--font-bricolage); font-weight: 800; font-size: clamp(1.1rem, 2.5vw, 1.35rem); color: var(--h-heading); margin: 0 }
        .ld-price-period { font-family: var(--font-nunito); font-size: .72rem; color: var(--h-muted); font-weight: 600; margin: 2px 0 0 }

        /* ── Sidebar ── */
        .ld-side-card { padding: clamp(.75rem, 2vw, 1rem) }
        .ld-side-title { font-family: var(--font-bricolage); font-weight: 800; font-size: .82rem; color: var(--h-heading); margin: 0 0 .75rem; display: flex; align-items: center; gap: 7px }
        .ld-facts { display: flex; flex-direction: column; gap: 10px }
        .ld-fact { display: flex; align-items: center; gap: 8px }
        .ld-fact-icon { width: 28px; height: 28px; border-radius: 8px; flex-shrink: 0; display: flex; align-items: center; justify-content: center }
        .ld-fact-label { font-family: var(--font-nunito); font-size: .64rem; color: var(--h-muted); margin: 0; font-weight: 600 }
        .ld-fact-val { font-family: var(--font-nunito); font-size: .78rem; color: var(--h-heading); margin: 0; font-weight: 700 }
        .ld-fact-link { font-family: var(--font-nunito); font-size: .75rem; color: var(--h-accent); font-weight: 700; text-decoration: none; display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap }
        .ld-socials { display: flex; flex-direction: column; gap: 6px }
        .ld-social { display: flex; align-items: center; gap: 8px; padding: 7px 10px; border-radius: 10px; background: var(--h-bg); text-decoration: none; font-family: var(--font-nunito); font-size: .78rem; color: var(--h-heading); font-weight: 600; transition: all .2s }
        .ld-social:hover { background: var(--h-border-light) }
        .ld-social-icon { width: 26px; height: 26px; border-radius: 7px; display: flex; align-items: center; justify-content: center; flex-shrink: 0 }
        .ld-side-cta { border-radius: 20px; border: 1.5px solid; padding: clamp(.85rem, 2vw, 1.15rem); text-align: center }
        .ld-side-cta-icon { width: 36px; height: 36px; border-radius: 11px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 8px }
        .ld-side-cta-title { font-family: var(--font-bricolage); font-weight: 800; font-size: .88rem; color: var(--h-heading); margin: 0 0 4px }

        /* ── Related ── */
        .ld-related { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 10px }
        .ld-related-card { display: flex; gap: 10px; padding: 12px; border-radius: 14px; background: var(--h-bg); border: 1px solid var(--h-border-light); text-decoration: none; align-items: center; transition: all .3s cubic-bezier(.16,1,.3,1) }
        .ld-related-card:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(0,0,0,.05) }
        .ld-related-logo { width: 40px; height: 40px; border-radius: 11px; flex-shrink: 0; overflow: hidden; border: 1px solid; display: flex; align-items: center; justify-content: center }
        .ld-related-logo img { width: 100%; height: 100%; object-fit: contain }
        .ld-related-name { font-family: var(--font-bricolage); font-weight: 800; font-size: .8rem; color: var(--h-heading); margin: 0 0 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap }
        .ld-related-tagline { font-family: var(--font-nunito); font-size: .7rem; color: var(--h-body); margin: 0 0 5px; line-height: 1.35; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden }
        .ld-related-arrow { color: var(--h-muted); flex-shrink: 0; transition: transform .2s }
        .ld-related-card:hover .ld-related-arrow { transform: translateX(3px); color: var(--h-accent) }

        /* ── Back link ── */
        .ld-back { display: inline-flex; align-items: center; gap: 5px; font-family: var(--font-nunito); font-size: .72rem; font-weight: 700; color: var(--h-accent); margin-top: 1.25rem; text-decoration: none }

        /* ── Lightbox ── */
        .ld-lightbox { position: fixed; inset: 0; z-index: 9999; background: rgba(0,0,0,.8); display: flex; align-items: center; justify-content: center; cursor: pointer; padding: 1rem }
        .ld-lightbox img { max-width: 92vw; max-height: 88vh; border-radius: 14px; object-fit: contain; box-shadow: 0 8px 40px rgba(0,0,0,.4) }
        .ld-lightbox-close { position: absolute; top: 14px; right: 14px; width: 36px; height: 36px; border-radius: 10px; background: rgba(255,255,255,.15); border: none; cursor: pointer; display: flex; align-items: center; justify-content: center }

        /* ═══ RESPONSIVE ═══ */
        @media (max-width: 900px) {
          .ld-grid { grid-template-columns: 1fr }
          .ld-sidebar { position: static; display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 10px }
          .ld-side-cta { grid-column: 1 / -1 }
        }
        @media (max-width: 600px) {
          .ld-hero-body { flex-direction: column; align-items: flex-start; gap: .65rem }
          .ld-logo { width: 52px; height: 52px; border-radius: 14px }
          .ld-logo-fallback { font-size: 1.3rem !important }
          .ld-title { font-size: 1.15rem }
          .ld-actions { width: 100% }
          .ld-btn-primary, .ld-btn-outline { flex: 1; justify-content: center; font-size: .75rem; padding: 8px 12px }
          .ld-features { grid-template-columns: 1fr }
          .ld-pricing { grid-template-columns: 1fr }
          .ld-gallery-item { width: 200px; height: 130px }
          .ld-related { grid-template-columns: 1fr }
          .ld-sidebar { grid-template-columns: 1fr }
          .ld-banner { padding: 1.25rem .85rem .85rem; min-height: 70px }
          .ld-section { padding: .85rem }
          .ld-meta-row { gap: 6px }
          .ld-meta { font-size: .64rem }
          .ld-crumbs { gap: 3px; font-size: .6rem }
          .ld-crumb { padding: 2px 6px; font-size: .58rem }
        }
        @media (max-width: 380px) {
          .ld-wrap { padding: 0 .5rem }
          .ld-card { border-radius: 14px }
          .ld-section { padding: .75rem }
          .ld-hero-body { padding: .75rem }
          .ld-logo { width: 44px; height: 44px; border-radius: 12px }
        }
      `})]})}}},e=>{e.O(0,[573,429,728,680,358],()=>e(e.s=5340)),_N_E=e.O()}]);